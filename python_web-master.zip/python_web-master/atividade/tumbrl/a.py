import secrets
print(secrets.token_hex(16))