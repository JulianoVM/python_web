from machine_learning_proj import app
from machine_learning_proj.clf_mlp import mlp
from machine_learning_proj.clf_dt import dt
from machine_learning_proj.clf_rf import rf
from machine_learning_proj.clf_knn import knn
from flask import render_template, request, redirect, url_for

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/process', methods=['POST'])
def process():
    selected_classifier = request.form['classificadores']

    return redirect(url_for('result', classifier=selected_classifier))

@app.route('/result/<classifier>')
def result(classifier):
    classifier = classifier.lower()

    return render_template(f'{classifier}.html', classifier=classifier)

@app.route('/classifier/<classifier>', methods=['POST'])
def classifier(classifier):
    if (classifier == 'KNN'):
        parameter1 = request.form['n_neighbors']
        parameter2 = request.form['leaf_size']

        accuracy, f1 = knn(parameter1, parameter2)

    if (classifier == 'MLP'):
        parameter1 = request.form['learning_rate_init']
        parameter2 = request.form['max_iter']
        parameter3 = request.form['random_state']

        accuracy, f1 = mlp(parameter1, parameter2, parameter3)

    if (classifier == 'DT'):
        parameter1 = request.form['max_depth']
        parameter2 = request.form['max_features']
        parameter3 = request.form['random_state']

        accuracy, f1 = dt(parameter1, parameter2, parameter3)

    if (classifier == 'RF'):
        parameter1 = request.form['n_estimators']
        parameter2 = request.form['max_leaf_nodes']
        parameter3 = request.form['random_state']

        accuracy, f1 = rf(parameter1, parameter2, parameter3)

    return render_template('index.html')
