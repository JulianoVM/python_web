from machine_learning_proj import app

if __name__ == '__main__':
    app.run(debug=True)